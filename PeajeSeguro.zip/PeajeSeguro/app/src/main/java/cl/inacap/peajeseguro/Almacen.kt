package cl.inacap.peajeseguro

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

class Almacen(contexto: Context) : SQLiteOpenHelper(contexto, "peaje.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE usuario (nombre TEXT PRIMARY KEY, rol TEXT NOT NULL, sal TEXT NOT NULL, hash TEXT NOT NULL, intentos INTEGER NOT NULL, bloqueo INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE evento (id INTEGER PRIMARY KEY AUTOINCREMENT, fecha INTEGER NOT NULL, texto TEXT NOT NULL)")
    }
    override fun onUpgrade(db: SQLiteDatabase, anterior: Int, nuevo: Int) {}
    override fun onOpen(db: SQLiteDatabase) {
        super.onOpen(db)
        val antiguos = mutableListOf<Pair<Long, String>>()
        db.rawQuery("SELECT id,texto FROM evento WHERE texto NOT LIKE 'v1:%'", null).use {
            while (it.moveToNext()) antiguos.add(it.getLong(0) to it.getString(1))
        }
        if (antiguos.isNotEmpty()) {
            db.beginTransaction()
            try {
                antiguos.forEach { (id, texto) ->
                    db.update("evento", ContentValues().apply { put("texto", cifrar(texto)) }, "id=?", arrayOf(id.toString()))
                }
                db.setTransactionSuccessful()
            } finally { db.endTransaction() }
        }
    }

    fun existeUsuario(): Boolean = readableDatabase.rawQuery("SELECT nombre FROM usuario LIMIT 1", null).use { it.moveToFirst() }
    fun crearUsuario(nombre: String, clave: String, rol: String, autorizado: Boolean = false): Boolean {
        if (nombre.isBlank() || clave.length < 8 || rol !in listOf("Administrador", "Operador", "Cliente")) return false
        if (!existeUsuario() && rol != "Administrador") return false
        if (existeUsuario() && !autorizado && rol != "Cliente") return false
        val sal = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val valores = ContentValues().apply {
            put("nombre", nombre.trim()); put("rol", rol); put("sal", codificar(sal)); put("hash", codificar(hash(clave, sal)))
            put("intentos", 0); put("bloqueo", 0)
        }
        return writableDatabase.insert("usuario", null, valores) != -1L
    }
    fun ingresar(nombre: String, clave: String): String {
        readableDatabase.rawQuery("SELECT rol,sal,hash,intentos,bloqueo FROM usuario WHERE nombre=?", arrayOf(nombre.trim())).use {
            if (!it.moveToFirst()) return "Credenciales incorrectas"
            val rol = it.getString(0); val sal = Base64.decode(it.getString(1), Base64.NO_WRAP)
            val esperado = Base64.decode(it.getString(2), Base64.NO_WRAP); val intentos = it.getInt(3); val bloqueo = it.getLong(4)
            if (System.currentTimeMillis() < bloqueo) return "Cuenta bloqueada temporalmente"
            val correcto = MessageDigest.isEqual(esperado, hash(clave, sal))
            val nuevos = if (correcto) 0 else if (bloqueo > 0) 1 else intentos + 1
            val valores = ContentValues().apply { put("intentos", nuevos); put("bloqueo", if (nuevos >= 3) System.currentTimeMillis() + 60_000 else 0L) }
            writableDatabase.update("usuario", valores, "nombre=?", arrayOf(nombre.trim()))
            return if (correcto) rol else if (nuevos >= 3) "Cuenta bloqueada por 1 minuto" else "Credenciales incorrectas"
        }
    }
    fun registrar(texto: String) {
        val valores = ContentValues().apply { put("fecha", System.currentTimeMillis()); put("texto", cifrar(texto.take(300))) }
        writableDatabase.insert("evento", null, valores)
    }
    fun eventos(): List<String> {
        val lista = mutableListOf<String>()
        readableDatabase.rawQuery("SELECT fecha,texto FROM evento ORDER BY id DESC LIMIT 50", null).use {
            while (it.moveToNext()) lista.add(java.text.SimpleDateFormat("dd/MM HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date(it.getLong(0))) + " · " + descifrar(it.getString(1)))
        }
        return lista
    }
    private fun hash(clave: String, sal: ByteArray): ByteArray {
        val spec = PBEKeySpec(clave.toCharArray(), sal, 120_000, 256)
        return try { SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded } finally { spec.clearPassword() }
    }
    private fun codificar(bytes: ByteArray) = Base64.encodeToString(bytes, Base64.NO_WRAP)
    private fun claveEventos(): SecretKey {
        val almacen = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existente = almacen.getKey("peaje_eventos", null)
        if (existente is SecretKey) return existente
        val generador = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generador.init(KeyGenParameterSpec.Builder("peaje_eventos", KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
        return generador.generateKey()
    }
    private fun cifrar(texto: String): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, claveEventos())
        return "v1:" + codificar(cipher.iv + cipher.doFinal(texto.toByteArray(Charsets.UTF_8)))
    }
    private fun descifrar(texto: String): String {
        if (!texto.startsWith("v1:")) return texto // Registros de versiones anteriores.
        return try {
            val bytes = Base64.decode(texto.removePrefix("v1:"), Base64.NO_WRAP)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, claveEventos(), GCMParameterSpec(128, bytes.copyOfRange(0, 12)))
            String(cipher.doFinal(bytes.copyOfRange(12, bytes.size)), Charsets.UTF_8)
        } catch (_: Exception) { "No se pudo descifrar el evento" }
    }
}
