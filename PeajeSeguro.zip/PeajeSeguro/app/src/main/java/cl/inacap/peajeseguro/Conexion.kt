package cl.inacap.peajeseguro

import android.util.Base64
import org.json.JSONObject
import java.io.BufferedReader
import java.io.BufferedWriter
import java.net.ServerSocket
import java.net.Socket
import java.security.SecureRandom

// Comunicación entre teléfonos en la misma red. No envía órdenes a la barrera.
class Conexion(private val informar: (String) -> Unit, private val recibido: (String) -> Unit) {
    private var servidor: ServerSocket? = null
    private var socket: Socket? = null
    private var salida: BufferedWriter? = null
    private var cifrado: CifradoWifi? = null
    private var sesion = ""
    private var enviados = 0L
    @Volatile private var activa = false
    @Volatile private var cerrada = false
    private var direccionSalida = ""

    fun iniciarServidor(codigo: String) = Thread {
        try {
            preparar(codigo); val server = ServerSocket(8989)
            synchronized(this) { if (cerrada) { server.close(); return@Thread }; servidor = server }
            informar("Esperando conexión en el puerto 8989")
            val conexion = server.accept()
            synchronized(this) { if (cerrada) { conexion.close(); return@Thread }; socket = conexion; servidor = null }
            server.close()
            atender(conexion, true)
        } catch (e: Exception) { informar("Conexión finalizada: ${e.message ?: "error"}"); cerrar() }
    }.start()

    fun conectar(ip: String, codigo: String) = Thread {
        try {
            preparar(codigo)
            val conexion = Socket()
            synchronized(this) { if (cerrada) { conexion.close(); return@Thread }; socket = conexion }
            conexion.connect(java.net.InetSocketAddress(ip.trim(), 8989), 8000)
            atender(conexion, false)
        } catch (e: Exception) { informar("Conexión finalizada: ${e.message ?: "error"}"); cerrar() }
    }.start()

    private fun preparar(codigo: String) {
        cifrado = CifradoWifi(codigo)
    }
    private fun atender(conexion: Socket, esServidor: Boolean) {
        conexion.soTimeout = 15000
        val entrada = conexion.getInputStream().bufferedReader()
        val escritor = conexion.getOutputStream().bufferedWriter(); salida = escritor
        if (esServidor) {
            val reto = aleatorio(); escribir(escritor, reto)
            val respuesta = descifrar(leer(entrada)); val partes = respuesta.split("|")
            require(partes.size == 2 && partes[0] == reto) { "Código incorrecto" }
            sesion = reto + partes[1]
            escribir(escritor, cifrar("OK|$sesion"))
        } else {
            val reto = leer(entrada); require(reto.length == 24) { "Respuesta inválida" }
            val propio = aleatorio(); sesion = reto + propio
            escribir(escritor, cifrar("$reto|$propio"))
            require(descifrar(leer(entrada)) == "OK|$sesion") { "Código incorrecto" }
        }
        synchronized(this) {
            if (cerrada) return
            direccionSalida = if (esServidor) "servidor" else "cliente"
            enviados = 0; activa = true
        }
        conexion.soTimeout = 0
        informar("Conectado de forma cifrada")
        var esperados = 0L
        while (activa) {
            val mensaje = JSONObject(descifrar(leer(entrada)))
            val direccionEsperada = if (esServidor) "cliente" else "servidor"
            require(mensajeValido(mensaje.getString("sesion"), mensaje.getString("direccion"), mensaje.getLong("numero"), sesion, direccionEsperada, esperados + 1)) { "Mensaje repetido o fuera de secuencia" }
            esperados++
            val texto = mensaje.getString("texto")
            require(texto.length <= 300) { "Mensaje demasiado largo" }
            recibido(texto)
        }
    }
    @Synchronized fun enviar(texto: String): Boolean {
        if (!activa || texto.isBlank() || texto.length > 300) return false
        return try {
            val numero = enviados + 1
            val mensaje = JSONObject().put("sesion", sesion).put("direccion", direccionSalida).put("numero", numero).put("texto", texto).toString()
            escribir(salida ?: return false, cifrar(mensaje)); enviados = numero; true
        } catch (e: Exception) {
            cerrar()
            informar("No se pudo enviar: ${e.message ?: "error de conexión"}")
            false
        }
    }
    @Synchronized fun cerrar() {
        cerrada = true
        activa = false
        try { socket?.close() } catch (_: Exception) {}
        try { servidor?.close() } catch (_: Exception) {}
        socket = null; servidor = null; salida = null; cifrado = null; sesion = ""
    }
    private fun aleatorio(): String = Base64.encodeToString(ByteArray(16).also { SecureRandom().nextBytes(it) }, Base64.NO_WRAP)
    private fun cifrar(texto: String): String = requireNotNull(cifrado).cifrar(texto)
    private fun descifrar(texto: String): String = requireNotNull(cifrado).descifrar(texto)
    private fun escribir(salida: BufferedWriter, texto: String) { salida.write(texto); salida.newLine(); salida.flush() }
    private fun leer(entrada: BufferedReader): String {
        val linea = StringBuilder()
        while (true) {
            val caracter = entrada.read()
            if (caracter == -1) throw IllegalStateException("El otro dispositivo se desconectó")
            if (caracter == '\n'.code) return linea.toString().removeSuffix("\r")
            require(linea.length < 8192) { "Mensaje demasiado largo" }
            linea.append(caracter.toChar())
        }
    }
}
