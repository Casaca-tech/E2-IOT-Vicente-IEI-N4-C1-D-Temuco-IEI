package cl.inacap.peajeseguro

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.MotionEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

class MainActivity : ComponentActivity() {
    private lateinit var almacen: Almacen
    private var ultimaActividad = System.currentTimeMillis()
    private var sesion by mutableStateOf("")
    private var nombreSesion by mutableStateOf("")
    private var estadoRed by mutableStateOf("Sin conexión")
    private var estadoBluetooth by mutableStateOf("Sin conexión Bluetooth")
    private var eventos by mutableStateOf(listOf<String>())
    private var conexion: Conexion? = null
    private var generacionConexion = 0
    private var bluetooth: android.bluetooth.BluetoothSocket? = null
    private val permisoBluetooth = registerForActivityResult(ActivityResultContracts.RequestPermission()) { concedido ->
        estadoBluetooth = if (concedido) "Permiso concedido. Selecciona el dispositivo nuevamente." else "Permiso Bluetooth denegado"
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        almacen = Almacen(this)
        actualizarEventos()
        setContent {
            MaterialTheme {
                LaunchedEffect(sesion) {
                    while (sesion.isNotEmpty()) {
                        delay(1000)
                        if (System.currentTimeMillis() - ultimaActividad >= 5 * 60_000) salir()
                    }
                }
                if (sesion.isEmpty()) Acceso() else Principal()
            }
        }
    }
    override fun dispatchTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_DOWN) ultimaActividad = System.currentTimeMillis()
        return super.dispatchTouchEvent(event)
    }
    override fun onDestroy() { conexion?.cerrar(); try { bluetooth?.close() } catch (_: Exception) {}; almacen.close(); super.onDestroy() }
    private fun salir() { generacionConexion++; conexion?.cerrar(); conexion = null; try { bluetooth?.close() } catch (_: Exception) {}; sesion = ""; nombreSesion = ""; estadoRed = "Sin conexión"; estadoBluetooth = "Sin conexión Bluetooth" }
    private fun nuevaConexion(): Conexion {
        generacionConexion++
        val actual = generacionConexion
        conexion?.cerrar()
        return Conexion({ mensaje -> runOnUiThread { if (actual == generacionConexion && sesion.isNotEmpty()) estadoRed = mensaje } }, { mensaje ->
            runOnUiThread { if (actual == generacionConexion && sesion.isNotEmpty()) registrar("Recibido por Wi-Fi: $mensaje") }
        }).also { conexion = it }
    }
    private fun actualizarEventos() { eventos = almacen.eventos() }
    private fun registrar(texto: String) { almacen.registrar(texto); actualizarEventos() }

    @Composable private fun Acceso() {
        var nombre by remember { mutableStateOf("") }; var clave by remember { mutableStateOf("") }
        var mensaje by remember { mutableStateOf("") }
        var mensajeExitoso by remember { mutableStateOf(false) }
        var creado by remember { mutableStateOf(almacen.existeUsuario()) }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Peaje Seguro", style = MaterialTheme.typography.headlineMedium)
            Text(if (creado) "Ingresa con una cuenta de este dispositivo" else "Crea una cuenta local en este dispositivo")
            OutlinedTextField(nombre, { nombre = it }, label = { Text("Usuario") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(clave, { clave = it }, label = { Text("Contraseña (mínimo 8 caracteres)") }, visualTransformation = PasswordVisualTransformation(), singleLine = true, modifier = Modifier.fillMaxWidth())
            if (!creado) {
                Text(if (!almacen.existeUsuario()) "La primera cuenta será administradora de este teléfono." else "La cuenta nueva tendrá el rol de cliente. Un administrador puede crear operadores y otros administradores.")
                Text("Las cuentas se guardan únicamente en este teléfono.")
            }
            Button(onClick = {
                mensajeExitoso = false
                if (!creado) {
                    val rolNuevo = if (almacen.existeUsuario()) "Cliente" else "Administrador"
                    if (almacen.crearUsuario(nombre, clave, rolNuevo)) { creado = true; clave = ""; mensaje = "Cuenta creada de manera exitosa"; mensajeExitoso = true }
                    else mensaje = "El usuario ya existe o los datos no son válidos. Usa una contraseña de al menos 8 caracteres."
                } else {
                    val resultado = almacen.ingresar(nombre, clave); clave = ""
                    if (resultado in listOf("Administrador", "Operador", "Cliente")) { nombreSesion = nombre.trim(); sesion = resultado; ultimaActividad = System.currentTimeMillis(); registrar("Inicio de sesión: $resultado") }
                    else mensaje = resultado
                }
            }, modifier = Modifier.fillMaxWidth()) { Text(if (creado) "Ingresar" else "Crear cuenta") }
            if (almacen.existeUsuario()) {
                TextButton(onClick = { creado = !creado; nombre = ""; clave = ""; mensaje = ""; mensajeExitoso = false }) {
                    Text(if (creado) "Crear otra cuenta" else "Ya tengo una cuenta")
                }
            }
            Text(mensaje, color = if (mensajeExitoso) androidx.compose.ui.graphics.Color(0xFF1B5E20) else MaterialTheme.colorScheme.error)
        }
    }

    @Composable private fun Principal() {
        var pantalla by remember { mutableStateOf("Monitoreo") }
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            Text("Peaje Seguro · $sesion ($nombreSesion)", style = MaterialTheme.typography.titleLarge)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                TextButton(onClick = { pantalla = "Monitoreo" }) { Text("Monitoreo") }
                TextButton(onClick = { pantalla = "Conexión" }) { Text("Conexión") }
                TextButton(onClick = { salir() }) { Text("Cerrar sesión") }
            }
            if (sesion == "Administrador") TextButton(onClick = { pantalla = "Usuarios" }) { Text("Administrar usuarios") }
            when (pantalla) { "Monitoreo" -> Monitoreo(); "Usuarios" -> AdministrarUsuarios(); else -> Conexiones() }
        }
    }

    @Composable private fun AdministrarUsuarios() {
        var nombre by remember { mutableStateOf("") }; var clave by remember { mutableStateOf("") }
        var rol by remember { mutableStateOf("Cliente") }; var aviso by remember { mutableStateOf("") }
        var exitoso by remember { mutableStateOf(false) }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Crear usuario local", style = MaterialTheme.typography.titleMedium)
            Text("Solo un administrador con sesión iniciada puede crear operadores o administradores en este teléfono.")
            OutlinedTextField(nombre, { nombre = it }, label = { Text("Usuario") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(clave, { clave = it }, label = { Text("Contraseña (mínimo 8 caracteres)") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
            listOf("Administrador", "Operador", "Cliente").forEach { opcion ->
                Row { RadioButton(rol == opcion, onClick = { rol = opcion }); Text(opcion, Modifier.padding(top = 12.dp)) }
            }
            Button(onClick = {
                exitoso = sesion == "Administrador" && almacen.crearUsuario(nombre, clave, rol, autorizado = true)
                aviso = if (exitoso) "Cuenta creada de manera exitosa" else "Usuario duplicado o datos no válidos"
                if (exitoso) { nombre = ""; clave = ""; registrar("Cuenta local creada: $rol") }
            }) { Text("Crear cuenta") }
            Text(aviso, color = if (exitoso) androidx.compose.ui.graphics.Color(0xFF1B5E20) else MaterialTheme.colorScheme.error)
        }
    }

    @Composable private fun Monitoreo() {
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) {
                Text("Estado de comunicaciones", style = MaterialTheme.typography.titleMedium)
                Text("Wi-Fi: $estadoRed"); Text("Bluetooth: $estadoBluetooth")
                Text("La barrera se opera físicamente. Esta app no envía órdenes de apertura.")
            } }
            Text("Eventos guardados en este dispositivo", style = MaterialTheme.typography.titleMedium)
            if (eventos.isEmpty()) Text("Sin eventos")
            LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) { items(eventos) { evento -> Card(Modifier.fillMaxWidth()) { Text(evento, Modifier.padding(12.dp)) } } }
        }
    }

    @Composable private fun Conexiones() {
        var codigo by remember { mutableStateOf("") }; var ip by remember { mutableStateOf("") }
        var texto by remember { mutableStateOf("") }; var aviso by remember { mutableStateOf("") }
        var enviando by remember { mutableStateOf(false) }
        val alcance = rememberCoroutineScope()
        var dispositivos by remember { mutableStateOf(listOf<Pair<String, String>>()) }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Comunicación entre teléfonos por Wi-Fi", style = MaterialTheme.typography.titleMedium)
            Text("Ambos teléfonos deben usar la misma red y el mismo código privado. El administrador espera la conexión; el cliente ingresa la IP del administrador.")
            OutlinedTextField(codigo, { codigo = it }, label = { Text("Código compartido (12 caracteres o más)") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
            if (sesion == "Administrador") Button(onClick = { if (codigo.length >= 12) nuevaConexion().iniciarServidor(codigo) else aviso = "Código demasiado corto" }) { Text("Esperar conexión") }
            if (sesion == "Cliente") {
                OutlinedTextField(ip, { ip = it }, label = { Text("IP del administrador") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Button(onClick = { if (codigo.length >= 12 && ip.isNotBlank()) nuevaConexion().conectar(ip, codigo) else aviso = "Ingresa IP y código válido" }) { Text("Conectar") }
            }
            Text(estadoRed)
            OutlinedTextField(texto, { texto = it.take(300) }, label = { Text(if (sesion == "Cliente") "Solicitud de validación" else "Respuesta o estado") }, modifier = Modifier.fillMaxWidth())
            Button(enabled = !enviando, onClick = {
                val mensaje = texto
                val conexionActual = conexion
                val generacionActual = generacionConexion
                if (mensaje.isBlank() || conexionActual == null) {
                    aviso = "Conecta los dispositivos e ingresa un mensaje"
                } else {
                    enviando = true
                    alcance.launch {
                        val enviado = withContext(Dispatchers.IO) { conexionActual.enviar(mensaje) }
                        if (generacionActual == generacionConexion && sesion.isNotEmpty()) {
                            if (enviado) {
                                registrar("Enviado por Wi-Fi: $mensaje")
                                if (texto == mensaje) texto = ""
                                aviso = "Mensaje enviado"
                            } else aviso = "No se pudo enviar. Comprueba la conexión."
                        }
                        enviando = false
                    }
                }
            }) { Text(if (enviando) "Enviando..." else "Enviar mensaje") }
            Text(aviso)
            HorizontalDivider()
            if (sesion == "Operador") {
                Text("Monitoreo Bluetooth", style = MaterialTheme.typography.titleMedium)
                Text("Empareja el equipo en los ajustes Android. La app solo recibe texto del dispositivo; no envía comandos.")
                Button(onClick = { dispositivos = dispositivosEmparejados() }) { Text("Ver dispositivos emparejados") }
                dispositivos.forEach { (nombre, direccion) -> TextButton(onClick = { conectarBluetooth(direccion) }) { Text("$nombre ($direccion)") } }
                Text(estadoBluetooth)
            }
        }
    }
    private fun tienePermiso(): Boolean {
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            permisoBluetooth.launch(Manifest.permission.BLUETOOTH_CONNECT); return false
        }
        return true
    }
    @Suppress("MissingPermission")
    private fun dispositivosEmparejados(): List<Pair<String, String>> {
        if (!tienePermiso()) return emptyList()
        val adaptador = getSystemService(BluetoothManager::class.java)?.adapter
        if (adaptador == null || !adaptador.isEnabled) { estadoBluetooth = "Bluetooth no disponible o desactivado"; return emptyList() }
        return try { adaptador.bondedDevices.map { (it.name ?: "Dispositivo") to it.address } } catch (_: SecurityException) { estadoBluetooth = "Permiso Bluetooth requerido"; emptyList() }
    }
    @Suppress("MissingPermission")
    private fun conectarBluetooth(direccion: String) {
        if (!tienePermiso()) return
        Thread {
            try {
                try { bluetooth?.close() } catch (_: Exception) {}
                val dispositivo = getSystemService(BluetoothManager::class.java).adapter.getRemoteDevice(direccion)
                val socket = dispositivo.createRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805f9b34fb")); bluetooth = socket
                runOnUiThread { estadoBluetooth = "Conectando..." }; socket.connect()
                runOnUiThread { estadoBluetooth = "Conectado; esperando datos" }
                val entrada = socket.inputStream.bufferedReader()
                while (true) {
                    val linea = entrada.readLine() ?: break
                    runOnUiThread { if (sesion == "Operador") registrar("Bluetooth: ${linea.take(200)}") }
                }
                socket.close(); runOnUiThread { estadoBluetooth = "Bluetooth desconectado" }
            } catch (e: Exception) { runOnUiThread { estadoBluetooth = "Bluetooth: ${e.message ?: "error de conexión"}" } }
        }.start()
    }
}
