package cl.inacap.peajeseguro

import java.security.SecureRandom
import java.util.Base64
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

class CifradoWifi(codigo: String) {
    private val clave: SecretKeySpec
    init {
        require(codigo.length >= 12) { "El código compartido debe tener al menos 12 caracteres" }
        val spec = PBEKeySpec(codigo.toCharArray(), "PeajeSeguro-U2-v1".toByteArray(), 120_000, 256)
        val bytes = try { SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded } finally { spec.clearPassword() }
        clave = SecretKeySpec(bytes, "AES")
    }
    fun cifrar(texto: String): String {
        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, clave, GCMParameterSpec(128, iv))
        return Base64.getEncoder().encodeToString(iv + cipher.doFinal(texto.toByteArray(Charsets.UTF_8)))
    }
    fun descifrar(texto: String): String {
        val datos = Base64.getDecoder().decode(texto)
        require(datos.size >= 28)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, clave, GCMParameterSpec(128, datos.copyOfRange(0, 12)))
        return String(cipher.doFinal(datos.copyOfRange(12, datos.size)), Charsets.UTF_8)
    }
}

fun mensajeValido(sesion: String, direccion: String, numero: Long, sesionEsperada: String, direccionEsperada: String, numeroEsperado: Long): Boolean {
    return sesion == sesionEsperada && direccion == direccionEsperada && numero == numeroEsperado
}
