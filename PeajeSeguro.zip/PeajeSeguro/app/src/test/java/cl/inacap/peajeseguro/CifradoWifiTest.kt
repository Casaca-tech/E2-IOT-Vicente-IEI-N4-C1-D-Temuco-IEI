package cl.inacap.peajeseguro

import org.junit.Assert.*
import org.junit.Test
import java.util.Base64

class CifradoWifiTest {
    @Test fun mensajeSeRecuperaConMismoCodigo() {
        val original = "Estado: vehículo presente"
        val emisor = CifradoWifi("clave compartida 123")
        val receptor = CifradoWifi("clave compartida 123")
        val cifrado = emisor.cifrar(original)
        assertNotEquals(original, cifrado)
        assertEquals(original, receptor.descifrar(cifrado))
        assertNotEquals(cifrado, emisor.cifrar(original))
    }
    @Test fun codigoDistintoNoDescifra() {
        val mensaje = CifradoWifi("clave compartida 123").cifrar("estado")
        assertThrows(Exception::class.java) { CifradoWifi("otra clave distinta").descifrar(mensaje) }
    }
    @Test fun alteracionSeRechaza() {
        val cifrado = CifradoWifi("clave compartida 123")
        val bytes = Base64.getDecoder().decode(cifrado.cifrar("estado"))
        bytes[bytes.lastIndex] = (bytes.last().toInt() xor 1).toByte()
        assertThrows(Exception::class.java) { cifrado.descifrar(Base64.getEncoder().encodeToString(bytes)) }
    }
    @Test fun rechazaRepeticionOtraSesionYReflejo() {
        assertTrue(mensajeValido("sesionA", "cliente", 2, "sesionA", "cliente", 2))
        assertFalse(mensajeValido("sesionA", "cliente", 1, "sesionA", "cliente", 2))
        assertFalse(mensajeValido("sesionB", "cliente", 2, "sesionA", "cliente", 2))
        assertFalse(mensajeValido("sesionA", "servidor", 2, "sesionA", "cliente", 2))
    }
    @Test fun codigoCortoSeRechaza() {
        assertThrows(IllegalArgumentException::class.java) { CifradoWifi("corto") }
    }
}
