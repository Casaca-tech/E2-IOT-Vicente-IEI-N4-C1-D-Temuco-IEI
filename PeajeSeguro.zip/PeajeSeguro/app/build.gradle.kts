plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "cl.inacap.peajeseguro"
    compileSdk = 37
    defaultConfig { applicationId = "cl.inacap.peajeseguro"; minSdk = 26; targetSdk = 36; versionCode = 1; versionName = "1.0" }
    val clavePrueba = providers.gradleProperty("clavePrueba").orNull
    if (clavePrueba != null) {
        signingConfigs.create("firmaPrueba") {
            storeFile = file(clavePrueba); storePassword = "android"; keyAlias = "androiddebugkey"; keyPassword = "android"
        }
        buildTypes.getByName("debug").signingConfig = signingConfigs.getByName("firmaPrueba")
    }
    buildFeatures { compose = true }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2026.02.01"))
    implementation("androidx.activity:activity-compose:1.13.0")
    implementation("androidx.core:core-ktx:1.19.1")
    implementation("androidx.lifecycle:lifecycle-common:2.11.0")
    implementation("androidx.lifecycle:lifecycle-runtime:2.11.0")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    testImplementation("junit:junit:4.13.2")
}
